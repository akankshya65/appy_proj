package com.flp.fms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


import com.flp.fms.domain.Actor;
import com.flp.fms.domain.film;
import com.flp.fms.exceptions.DuplicateRecordException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class UserInteraction {

	IFilmService ifilmservice;
	IActorService iactorservice;
	Scanner sc=new Scanner(System.in);
	//static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public UserInteraction()
	{
	 ifilmservice=new FilmServiceImpl();
		 iactorservice=new ActorServiceImpl();
	}


	public void AddFilm() throws ParseException, FieldEmptyException, NegativeFieldException, DuplicateRecordException
	{
Map<Integer,Object> film_details=new HashMap();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
		System.out.println("Enter title");
		film_details.put(0,sc.next());
		
		System.out.println("Enter description");
		film_details.put(1,sc.next());
		
		System.out.println("Enter release date");
		
		film_details.put(2,dateFormat.parse(sc.next()));
		
		System.out.println("Enter rental duration");
		film_details.put(3,sc.nextInt());
		
		System.out.println("Enter rental rate");
		film_details.put(4,sc.nextInt());
		
		System.out.println("Enter length of the movie");
		film_details.put(5,sc.nextInt());
		
		System.out.println("Enter replacement cost");
		film_details.put(6,sc.nextInt());
		
		System.out.println("Enter rating");
		film_details.put(7,sc.nextInt());
		
		System.out.println("Enter special features");
		film_details.put(8,sc.next());
		
		//Language language=new Language();
		System.out.println("Enter language name");
		film_details.put(9,sc.next());
		
		
		
		System.out.println("Enter category name");
		film_details.put(10,sc.next());
	int j=11;
		System.out.println("enter no of actors");
		int noofactors=sc.nextInt();
		for(int i=1;i<=noofactors;i++){
			Map<Integer,Object> actor_details=new HashMap();
			System.out.println("Enter the actor first name");
			actor_details.put(1,sc.next());
			System.out.println("Enter the actor last name");
			actor_details.put(2,sc.next());
			film_details.put(j,actor_details);
			j++;
		}
		System.out.println(ifilmservice.AddFilm(film_details));}
	public void ModifyFilm() throws ParseException, IOException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
		Map<Integer,Object> newDetails=new HashMap();
		//List newDetails=new ArrayList();
		System.out.println("enter title,releaseyear and rating of the film to modify");
		String titlePrevious=sc.nextLine();
		Date releaseYearprev=dateFormat.parse(sc.next());
		Integer ratingPrevious=sc.nextInt();
		newDetails.put(1,titlePrevious);
		newDetails.put(2,releaseYearprev);
		newDetails.put(3,ratingPrevious);
		System.out.println("enter choice to modify 1.title 2.description 3.language 4.rental_duration 5.rental_rate 6.length 7.replacement_cost 8.rating 9.special_features 10.category");
		int choice=sc.nextInt();
		switch(choice){
		 
		case 1:System.out.println("enter new title");
		String title=sc.next();
		newDetails.put(4, title);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		case 2:System.out.println("enter new description");
		String description=sc.next();
		newDetails.put(5, description);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		case 3:System.out.println("enter new language");
		String language=sc.next();
		newDetails.put(6, language);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		case 4:System.out.println("enter new rental_duration");
		int rentalDuration=sc.nextInt();
		newDetails.put(7, rentalDuration);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		case 5:System.out.println("enter new rental_rate");
		int rentalRate=sc.nextInt();
		newDetails.put(8, rentalRate);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		case 6:System.out.println("enter new length");
		int length=sc.nextInt();
		newDetails.put(9, length);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		case 7:System.out.println("enter new replacement cost");
		int replacementCost=sc.nextInt();
		newDetails.put(10, replacementCost);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		 
		case 8:System.out.println("enter new rating");
		int rating=sc.nextInt();
		newDetails.put(11, rating);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		 
		 
		case 9:System.out.println("enter new special features");
		String specialFeatures=sc.nextLine();
		newDetails.put(12, specialFeatures);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		case 10:System.out.println("enter new Category");
		String category=sc.nextLine();
		newDetails.put(13, category);
		System.out.println(ifilmservice.ModifyFilm(newDetails));
		break;
		}
		
	}
	
	public void RemoveFilm() throws NegativeFieldException, FieldEmptyException, RecordNotFoundException
	{
		System.out.println("Enter the film id to remove");
		int film_id=sc.nextInt();
		if(ifilmservice.RemoveFilm(film_id))
		{
			System.out.println("film removed");
		}
		else
		{
			System.out.println("film Not Found");
		}
	}
	
	public void SearchFilm() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
	{
		System.out.println("Enter the film id to search");
		int film_id=sc.nextInt();
		film film=ifilmservice.SearchFilm(film_id);
		if(film !=null)
		{
			System.out.println("Found the movie");
		}
		else
		{
			System.out.println("Not Found");
		}
	}
	
	public void getAllFilm()
	{
		List<film> films=ifilmservice.getAllfilm();
		System.out.println("Details of the films are: "+films);
	}
	
	public void AddActor() throws FieldEmptyException, IOException
	{
		Actor actor=new Actor();
		System.out.println("Enter the actor's first name");
		String first_name=sc.nextLine();
		System.out.println("Enter the actor's last name");
		String last_name=sc.nextLine();
		
		if(iactorservice.AddActor(first_name,last_name)!=null)
		System.out.println("Actor added successfully");
		else
			System.out.println("Actor not added successfully");
	}
	
	public boolean ModifyActor() throws IOException
	{
		System.out.println("Enter the actor id");
		int actorId=sc.nextInt();
		
		System.out.println("Enter the actor first name");
		String first_name=sc.next();
		System.out.println("Enter the actor last name");
		String last_name=sc.next();
		System.out.println("Modified details:"+iactorservice.ModifyActor(actorId,first_name,last_name));
		return true;	
	}
	
	public boolean RemoveActor() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException 
	{
		System.out.println("Enter the actor id");
		int actor_id=sc.nextInt();
		if(iactorservice.RemoveActor(actor_id))
		{
			System.out.println("Actor Successfully removed");
			return true;
		}
		else
		{
		return false;
		}
	}
	
	public Actor SearchActor() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
	{
		System.out.println("Enter the actor id to search");
		int actor_id=sc.nextInt();
		Actor actor=iactorservice.SearchActor(actor_id);
		if(actor !=null)
		{
			System.out.println("Found: "+actor);
		}
		else
		{
			System.out.println("Not Found");
		}
		return actor;
	}
	
	public void getAllActor()
	{
		List<Actor> actors= iactorservice.getAllActor();
		System.out.println("All actors details are "+actors);
	}
	}


