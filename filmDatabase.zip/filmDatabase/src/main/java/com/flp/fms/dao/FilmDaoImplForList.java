package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.fms.exceptions.RecordNotFoundException;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;

public class FilmDaoImplForList implements IFilmDao{

	private EntityManagerFactory emf=Persistence.createEntityManagerFactory("hello");
	private EntityManager em=emf.createEntityManager();
	public String AddFilm(film film) {
		
		if(film!=null){


			em.getTransaction().begin();
			em.persist(film);
			em.getTransaction().commit();
			return "added Successfully";
		}

		return "unsuccessfull";
	
	}
	public String ModifyFilm(film film) {
		em.getTransaction().begin();
		em.persist(film);
		em.getTransaction().commit();

		return "successfull";
	}
		
	
	public boolean RemoveFilm(int film_id) throws RecordNotFoundException {
		film film=SearchFilm(film_id);
		if(film!=null)
		{
			em.getTransaction().begin();
			em.remove(film);
			em.getTransaction().commit();

			
			return true;
		}
		else
		
			throw new RecordNotFoundException();
	}
	
	public film SearchFilm(int film_id) {
		return em.find(film.class, film_id);
		
	}
	public List<film> getAllfilm() {
		
		TypedQuery<film> query = em.createQuery("Select e from film e",film.class);
		return query.getResultList();
		
		}
	
	public Language findLanguagebyName(String name){
		TypedQuery<Language> query = em.createQuery("Select l from Language l",Language.class);
System.out.println(name);
System.out.println(query.getResultList());
		List<Language> languages=query.getResultList();
		for(Language l:languages)
		{
			System.out.println(l);
			if(l.getName().equals(name))
			{
				return l;
			}
		}
		return null;
	}
	
    public Category findCategoryByName(String string)
    {
           TypedQuery<Category> query = em.createQuery("Select l from Category l",Category.class);
                       
           List<Category> category=query.getResultList();
           for(Category l:category)
           {
                  System.out.println(l);
                  if(l.getName().equals(string))
                  {
                        return l;
                  }
           }
           return null;
    }
    public film SearchFilmByDetails(String title,Date release_year,int rating) {
		TypedQuery<film> query = em.createQuery("Select e from film e",film.class);
	//	return query.getResultList();
		List<film> films=new ArrayList<film>();
		for(film f:query.getResultList())
		{
			if(f.getTitle().equals(title) && f.getRelease_year().equals(release_year) && f.getRating()==rating)
			{
				films.add(f);
				return f;
			/*	return (film) films;*/
			}
		
		
		}
		return null;
    }
	/*@Override
	public film SearchFilmByDetails(String string, Date date, Integer integer) {
		// TODO Auto-generated method stub
		return null;
	}
    */
		//return null;
    
    }

	

