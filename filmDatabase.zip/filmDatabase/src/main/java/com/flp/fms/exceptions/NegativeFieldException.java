package com.flp.fms.exceptions;

public class NegativeFieldException  extends Exception {

}
