package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;

import com.flp.fms.exceptions.RecordNotFoundException;

public interface IActorService {
	
	public Actor AddActor(String first_name,String last_name) throws FieldEmptyException;
	public boolean ModifyActor(int actor_id,String first_name,String last_name);
	public boolean RemoveActor(int actor_id) throws FieldEmptyException, NegativeFieldException, RecordNotFoundException;
	public Actor SearchActor(int actor_id) throws FieldEmptyException, NegativeFieldException, RecordNotFoundException;
	List<Actor> getAllActor();

}
