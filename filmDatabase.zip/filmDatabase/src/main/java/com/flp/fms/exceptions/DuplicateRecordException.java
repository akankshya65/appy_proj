package com.flp.fms.exceptions;

public class DuplicateRecordException extends Exception {

}
