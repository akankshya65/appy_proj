package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.film;
import com.flp.fms.service.FilmServiceImpl;
import com.google.gson.Gson;

public class GetAllFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("application/json");
		
		FilmServiceImpl ifilmservice=new FilmServiceImpl();
		
		
		List<film> films=ifilmservice.getAllfilm();
		
		
		Gson gson=new Gson();
		
		String myJsonFilm=gson.toJson(films);
		
		
		out.println(myJsonFilm);
		//System.out.println(emps);
	
	}
}
