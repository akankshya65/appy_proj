package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;

public class ActorServiceImpl implements IActorService
{
	private IActorDao iactordao;
	public ActorServiceImpl(IActorDao iactordao)
	{
		super();
		this.iactordao=iactordao;
	}

	public ActorServiceImpl() {
		iactordao=new ActorDaoImplForList();
	}

	

	public Actor AddActor(String first_name, String last_name) throws FieldEmptyException {
		
		if(first_name==null || last_name==null){
			
			throw new FieldEmptyException();
	}

	else{
	Actor actor=new Actor();
	actor.setFirst_name(first_name);
	actor.setLast_name(last_name);
	return iactordao.AddActor(actor);
	}
	 
		
		
		
		
		
		
	}

	public boolean ModifyActor(int actor_id, String first_name, String last_name) {
		Actor actor2=iactordao.SearchActor(actor_id);
		
		
			if(actor2!=null)
				
		
		{
			actor2.setFirst_name(first_name);
			actor2.setLast_name(last_name);
			if(iactordao.ModifyActor(actor2))
			return true ;
		}
		
	
		
		return false;
		
	}

	public boolean RemoveActor(int actor_id)  throws FieldEmptyException, NegativeFieldException, RecordNotFoundException{
		if(actor_id==0)
		{
			throw new FieldEmptyException();
		}
		else if(actor_id<0){
			throw new NegativeFieldException();
		}
		else if(iactordao.RemoveActor(actor_id)==true)
		{
			 return iactordao.RemoveActor(actor_id);
		}
		else
	throw new RecordNotFoundException();
    }
	

	public Actor SearchActor(int actor_id) throws FieldEmptyException,NegativeFieldException,RecordNotFoundException {
		
		if(actor_id==0)
		{
			throw new FieldEmptyException();
		}
		else if(actor_id<0){
			throw new NegativeFieldException();
		}
		else if(iactordao.SearchActor(actor_id)!=null)
			return iactordao.SearchActor(actor_id);
		else 
			throw new RecordNotFoundException();
		
	}

	public List<Actor> getAllActor() {
		
		return iactordao.getAllActor();
	}
	/*public boolean findActor(int actor_id)
	{
		return false;
		
	}*/

}
