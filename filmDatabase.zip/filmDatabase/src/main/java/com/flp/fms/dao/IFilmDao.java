package com.flp.fms.dao;

import java.util.Date;
import java.util.List;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;
import com.flp.fms.exceptions.RecordNotFoundException;

public interface IFilmDao {
public String AddFilm(film film);
public String ModifyFilm(film film);
public boolean RemoveFilm(int film_id) throws RecordNotFoundException;
public film SearchFilm(int film_id);
List<film> getAllfilm();
public Language findLanguagebyName(String string);
public Category findCategoryByName(String string);
public film SearchFilmByDetails(String title,Date release_year,int rating); 
//public film SearchFilmByDetails(String string,Date date,int int1); 

}
