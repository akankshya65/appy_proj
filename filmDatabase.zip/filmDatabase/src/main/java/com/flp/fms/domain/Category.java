package com.flp.fms.domain;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
public class Category {
	
	
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", name=" + name + ", last_update=" + last_update + "]";
	}
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private int category_id;
	private String name;
	@Column(nullable=false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date last_update=new Date(); 


	@OneToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL},mappedBy="category")
	private Set<film> film=new HashSet<film>();

   






	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getLast_update() {
		return last_update;
	}
	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}
}

