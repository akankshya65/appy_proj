
package com.flp.fms.test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.flp.fms.exceptions.DuplicateRecordException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;



public class ActorTest {
	
	
	@Mock
	IActorDao iactorDao;
	
	IActorService iactorService;

	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	@Before
	public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);	
		iactorService=new ActorServiceImpl(iactorDao);
	}

	
	
	
	       
	
	
	
	/*//createActor must return valid with valid inputs
			@Test
			public void createActorWillReturnValidWithValidInputs() throws FieldEmptyException {
				
			
				
				Actor actor=new Actor();
		
				actor.setFirst_name("xyz");
				actor.setLast_name("zyx");

				Mockito.when(iactorDao.AddActor(actor)).thenReturn(actor);
				
				
				assertEquals(actor,iactorService.AddActor("xyz","zyx"));
			
			}*/
			
			
			
			
			
			
			
			//createActor must return null when any input is null
			
			@Test(expected=com.flp.fms.exceptions.FieldEmptyException.class)
			public void createActorWillReturnNullWithNullInputs() throws FieldEmptyException, NegativeFieldException{
				String firstName=null;
				String lastName=null;
				iactorService.AddActor(firstName,lastName);
				
				
			}
			
			
			
			
			
			
			//removeActor must return valid when inputs are valid
			
			@Test
			public void removeFilmWillReturnValidWithValidInputs() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException{
				
				Mockito.when(iactorDao.RemoveActor(1)).thenReturn(true);
				
				assertEquals(true,iactorService.RemoveActor(1));
			}
			
			
			
			
			//removeActor must return null with null inputs
			
			@Test(expected = com.flp.fms.exceptions.FieldEmptyException.class)
			public void removeActorWillReturnNullWithIdZero() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException{
				
				assertEquals(false,iactorService.RemoveActor(0));
			}
			
			
			
			//removeActor must return null when record is not present
			
			@Test(expected = com.flp.fms.exceptions.RecordNotFoundException.class)
			public void removeActorWillReturnNullWithNoRecord() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException{
				Actor actor=new Actor();
				Mockito.when(iactorService.SearchActor(120)).thenReturn(null);
				assertEquals(false,iactorService.RemoveActor(120));
			}
	
			
			
			
			

			//removeActor must return null with invalid inputs

			@Test(expected = com.flp.fms.exceptions.NegativeFieldException.class)
			public void whenTheidIsZeroInRemoveActorThrowException() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
			{
				iactorService.RemoveActor(-10);
			}
			
			
			//searchActor must return null with  null inputs
			
			@Test(expected = com.flp.fms.exceptions.FieldEmptyException.class)
			public void whenTheidIsZeroInSearchActorThrowException() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
			{
				iactorService.SearchActor(0);
			}
			
			
			//searchActor must return null with  invalid inputs
			
			@Test(expected = com.flp.fms.exceptions.NegativeFieldException.class)
					public void whenTheidIsNegativeInSearchActorThrowException() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
					{
						iactorService.SearchActor(-1);
					}
			
			
			
			
			//searchActor must return valid with  valid inputs
			
			@Test
			public void whenTheidIsValidInSearchActorItShouldReturnValid() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
			{
					Actor actor=new Actor();
					Mockito.when(iactorDao.SearchActor(2)).thenReturn(actor);
						
					assertEquals(actor,iactorService.SearchActor(2));
			}
			
			
			
			
			
			//searchActor must return null with  no record
			
			@Test(expected = com.flp.fms.exceptions.RecordNotFoundException.class)
			public void whenTheidIsNotPresentInSearchActorThrowException() throws FieldEmptyException, NegativeFieldException, RecordNotFoundException
			{
				iactorService.SearchActor(121);
			}
			
			
			
}








