package com.flp.fms.service;


import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.exceptions.DuplicateRecordException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;
import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;

public  class FilmServiceImpl implements IFilmService {
	private IFilmDao ifilmdao;
	public FilmServiceImpl(IFilmDao ifilmdao)
	{
		super();
		this.ifilmdao=ifilmdao;
	}

	public FilmServiceImpl() {
		ifilmdao=new FilmDaoImplForList();
	}

	

	public String AddFilm(Map film_details) throws  ParseException, FieldEmptyException, NegativeFieldException,DuplicateRecordException {
		film film=new film();
		film.setTitle((String) film_details.get(0));
		film.setDescription((String) film_details.get(1));
		film.setRelease_year((Date) film_details.get(2));
		film.setRental_duration( (Integer) film_details.get(3));
		film.setRental_rate((Integer) film_details.get(4));
		film.setLength((Integer) film_details.get(5));
		film.setReplacement_cost( (Integer) film_details.get(6));
		film.setRating((Integer) film_details.get(7));
		film.setSpecial_features((String) film_details.get(8));
		Language language1=ifilmdao.findLanguagebyName((String) film_details.get(9));
		if(language1==null)
		{
			 Language language=new Language();
			 language.setName((String) film_details.get(9));
			 film.setLanguage(language);
		}
		else{
		film.setLanguage(language1);}
		Category category1=ifilmdao.findCategoryByName((String) film_details.get(10));
	    if(category1==null)
	    {
	           Category category=new Category();
	           category.setName((String) film_details.get(10));
	           film.setCategory(category);
	          
	    }
	    else
	    {
	           film.setCategory(category1);
	    }
		
		Language language=new Language();
		language.setName((String) film_details.get(9));
		
		
		film.setLanguage(language); 
		Category cat=new Category();
		cat.setName((String) film_details.get(10));
		film.setCategory(cat);
		
		for(int i=11;i<film_details.size();i++)
		{
			Actor actor=new Actor();
			Map<Integer,Object> actor_details=new HashMap();
			actor.setFirst_name((String) actor_details.get(0));
			actor.setLast_name((String) actor_details.get(1));
			film.getActor().add(actor);
		}
		
		return ifilmdao.AddFilm(film);
	}
		
		
		
		
	

	public String ModifyFilm(Map film_details) {
		film film2=ifilmdao. SearchFilmByDetails(((String)film_details.get(1)),((Date) film_details.get(2)),((Integer) film_details.get(3)));
		
		
		
		if(film2!=null){
		if(film_details.get(4)!=null){
			film2.setTitle((String)film_details.get(4));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(5)!=null){
			film2.setDescription((String)film_details.get(5));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(6)!=null){
			Language language=new Language();
			language.setName((String)film_details.get(6));
			film2.setLanguage(language);
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(7)!=null){
			film2.setRental_duration(((Integer)film_details.get(7)));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(8)!=null){
			film2.setRental_rate(((Integer)film_details.get(8)));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(9)!=null){
			film2.setLength((((Integer)film_details.get(9))));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(10)!=null){
			film2.setReplacement_cost((((Integer)film_details.get(10))));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(11)!=null){
			film2.setRating((Integer)film_details.get(11));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(12)!=null){
			film2.setSpecial_features(((String)film_details.get(12)));
			return ifilmdao.ModifyFilm(film2);
			}
			else if(film_details.get(13)!=null){
			Category category=new Category();
			category.setName((String)film_details.get(13));
			film2.setCategory(category);
			return ifilmdao.ModifyFilm(film2);
			}
			else return null;}
	return null;}
		
		
	public boolean RemoveFilm(int film_id) throws FieldEmptyException, NegativeFieldException, RecordNotFoundException {
		
		if(film_id==0)
		{
			throw new FieldEmptyException();
		}
		else if(film_id<0){
			throw new NegativeFieldException();
		}
		else
	 return ifilmdao.RemoveFilm(film_id);
    }
	

	public film SearchFilm(int film_id) throws FieldEmptyException, NegativeFieldException, RecordNotFoundException {
		
		if(film_id==0)
		{
			throw new FieldEmptyException();
		}
		else if(film_id<0){
			throw new NegativeFieldException();
		}
		else if(ifilmdao.SearchFilm(film_id)!=null)
			return ifilmdao.SearchFilm(film_id);
		else 
			throw new RecordNotFoundException();
	}
	

	

	public List<film> getAllfilm() {
		return ifilmdao.getAllfilm();
	}

	
	
}

	

	

	

	
	

	

	
	

	
	

