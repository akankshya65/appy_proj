package com.flp.fms.exceptions;

public class RecordNotFoundException extends Exception{

}
