package com.flp.fms.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.film;
import com.flp.fms.exceptions.DuplicateRecordException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;

public interface IFilmService {
public String AddFilm(Map film_details) throws ParseException, FieldEmptyException, NegativeFieldException, DuplicateRecordException;
public String ModifyFilm(Map film_details);

public boolean RemoveFilm(int film_id) throws NegativeFieldException, FieldEmptyException, RecordNotFoundException;
public film SearchFilm(int film_id) throws FieldEmptyException, NegativeFieldException, RecordNotFoundException;
List<film> getAllfilm();
//public char[] ModifyFilm(Map<Integer, Object> newDetails);
//public Object AddFilm(Map<Integer, Object> film1);

}
