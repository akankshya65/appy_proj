package com.flp.fms.view;

import java.io.IOException;
import java.rmi.server.UID;
import java.text.ParseException;
import java.util.Scanner;

import com.flp.fms.exceptions.DuplicateRecordException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeFieldException;
import com.flp.fms.exceptions.RecordNotFoundException;


public class BootClass {

public static void main(String[] args) throws ParseException, NegativeFieldException, FieldEmptyException, RecordNotFoundException, DuplicateRecordException, IOException {
BootClass b=new BootClass();
Scanner sc=new Scanner(System.in);
 
while(true)
{
System.out.println("Menu:-");
System.out.println("0.AddActor");
System.out.println("1.ModifyActor");
System.out.println("2.RemoveActor");
System.out.println("3.SearchActor");
System.out.println("4.getAllActor");
System.out.println("5.AddFilm");
System.out.println("6.ModifyFilm");
System.out.println("7.RemoveFilm");
System.out.println("8.SearchFilm");
System.out.println("9.getAllFilm");
 
System.out.println("10.Exit");
System.out.println("Please enter your choice");
int ch = sc.nextInt();


b.menuSelection(ch);
}

}

private void menuSelection(int ch) throws ParseException, NegativeFieldException, FieldEmptyException, RecordNotFoundException, DuplicateRecordException, IOException
{
UserInteraction ui=new UserInteraction();
switch(ch)
{
case 0:ui.AddActor();
break;
case 1:ui.ModifyActor();
break;
case 2:ui.RemoveActor();
break;
case 3:ui.SearchActor();
break;
case 4:ui.getAllActor();
break;
case 5:ui.AddFilm();
break;
case 6:ui.ModifyFilm();
break;
case 7:ui.RemoveFilm();
break;
case 8:ui.SearchFilm();
break;
case 9:ui.getAllFilm();
break;
}
}

}