package com.flp.fms.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
public class Language {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private int language_id;
private  String name;


@OneToMany(fetch = FetchType.LAZY,cascade = {CascadeType.ALL},mappedBy="language")
private Set<film> film=new HashSet<film>();

@Column(nullable=false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
@Temporal(TemporalType.TIMESTAMP)
private Date last_update=new Date(); 



public int getLanguage_id() {
	return language_id;
}
public void setLanguage_id(int language_id) {
	this.language_id = language_id;
}
public  String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getLast_update() {
	return last_update;
}
public void setLast_update(Date last_update) {
	this.last_update = last_update;
}
@Override
public String toString() {
	return "Language [language_id=" + language_id + ", name=" + name + ", last_update=" + last_update + "]";
}

}
